﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Meme_L_O_R_D_Z___Forms
{
    public partial class AddCreditCardForm : Form


    {
        public AddCreditCardForm()
        {
            InitializeComponent();
            /*
             * This won't work since the form doesn't have variables
             * 
            this.cardName = "";
            this.securitynumber = 0;
            this.cardnumber = 0;
            this.cardtype = "";
            this.address = "";
            this.zipcode = 0;
            this.city = " ";
            this.state = " ";
            this.street = " ";
            */
        }

        // function to add a credit card to the database (below)
        // By Nathan Drieling
        private void AddCreditCard(object sender, EventArgs e)
        {
            bool flag = false;

            /*Isaac created these variables*/
            string cardtype = "Z U C C";
            int cardnumber;
            string city;
            string state;
            int securitynumber;
            string street;
            int zipcode;

            // logic:
            // take credit card name entered from form
            // if visa is chosen, use the visa
            // if mastercard is chosen, use the mastercard
            // if american express is chosen, use that card
            // if EBT.. use EBT
            // take card number entered
            // take security number
            // set all of these equal to the fields in the database
            //done

            // gets users card information

            /*Didn't initialize vairbales*/
            /*Also did some variable name changing, didn't match up to the ones I had for the form*/

            if (MCradioB.Checked)
            {
                cardtype = "MasterCard";
            }
            else if (AEradioB.Checked)
            {
                cardtype = "American Express";
            }
            else if (VISAradioB.Checked)
            {
                cardtype = "Visa";
            }
            else if (EBTradioB.Checked)
            {
                cardtype = "EBT";
            }

            /*These were never initialized*/
            /*Also did more name changing*/
            cardnumber = int.Parse(cardNumberTextBox.Text);
            city = cityTextBox.Text;
            state = stateTextBox.Text;
            securitynumber = int.Parse(securityNumberTextBox.Text);
            street = streaNameTextBox.Text;
            zipcode = int.Parse(zipTextBox.Text);

            // connect to the database
            string connString = "Server=simplemodes.cyqmaqudzup4.us-east-2.rds.amazonaws.com;port=3307;Database=SimpleModes;user=SimpleModes;password=simplemodes";
            MySqlConnection conn = new MySqlConnection(connString);

            // SQL query to insert that data to database
            string query = "INSERT INTO customer(city, state, street, cardnumber, securitynumber, zipcode, cardtype) " +
                "VALUES('" + city + "','" + state + "','" + street + "','" + cardnumber + "','" + securitynumber + "','" + zipcode + "','" + cardtype + "') ;";
            MySqlCommand updateCmd = new MySqlCommand(query, conn);
            MySqlDataReader myReader;

            conn.Open();
            myReader = updateCmd.ExecuteReader();

            while (myReader.Read())
            {
                flag = true;
            }
            conn.Close();

            if (flag)
            {
                this.Hide();
                /*why only clear these two fields?*/
                /*Changed names since they didn't match*/
                /*What does cardName refer to??*/
                //cardName.Clear();
                zipTextBox.Clear();

                /*Isaac added these in*/
                cardNumberTextBox.Clear();
                cityTextBox.Clear();
                stateTextBox.Clear();
                securityNumberTextBox.Clear();
                streaNameTextBox.Clear();

                MCradioB.Checked = false;
                AEradioB.Checked = false;
                VISAradioB.Checked = false;
                EBTradioB.Checked = false;
            }
            else
                MessageBox.Show("Error in taking card data");
        }

        private void AddCreditCardButton_Click(object sender, EventArgs e)
        {
            bool flag = false;

            /*Isaac created these variables*/
            string cardtype = "Z U C C";
            int cardnumber;
            string city;
            string state;
            int securitynumber;
            string street;
            int zipcode;

            // logic:
            // take credit card name entered from form
            // if visa is chosen, use the visa
            // if mastercard is chosen, use the mastercard
            // if american express is chosen, use that card
            // if EBT.. use EBT
            // take card number entered
            // take security number
            // set all of these equal to the fields in the database
            //done

            // gets users card information

            /*Didn't initialize vairbales*/
            /*Also did some variable name changing, didn't match up to the ones I had for the form*/

            if (MCradioB.Checked)
            {
                cardtype = "MasterCard";
            }
            else if (AEradioB.Checked)
            {
                cardtype = "American Express";
            }
            else if (VISAradioB.Checked)
            {
                cardtype = "Visa";
            }
            else if (EBTradioB.Checked)
            {
                cardtype = "EBT";
            }

            /*These were never initialized*/
            /*Also did more name changing*/
            cardnumber = int.Parse(cardNumberTextBox.Text);
            city = cityTextBox.Text;
            state = stateTextBox.Text;
            securitynumber = int.Parse(securityNumberTextBox.Text);
            street = streaNameTextBox.Text;
            zipcode = int.Parse(zipTextBox.Text);

            // connect to the database
            string connString = "Server=simplemodes.cyqmaqudzup4.us-east-2.rds.amazonaws.com;port=3307;Database=SimpleModes;user=SimpleModes;password=simplemodes";
            MySqlConnection conn = new MySqlConnection(connString);

            // SQL query to insert that data to database
            string query = "INSERT INTO customer(city, state, street, cardnumber, securitynumber, zipcode, cardtype) " +
                "VALUES('" + city + "','" + state + "','" + street + "','" + cardnumber + "','" + securitynumber + "','" + zipcode + "','" + cardtype + "') ;";
            MySqlCommand updateCmd = new MySqlCommand(query, conn);
            MySqlDataReader myReader;

            conn.Open();
            myReader = updateCmd.ExecuteReader();

            while (myReader.Read())
            {
                flag = true;
            }
            conn.Close();

            if (flag)
            {
                this.Hide();
                /*why only clear these two fields?*/
                /*Changed names since they didn't match*/
                /*What does cardName refer to??*/
                //cardName.Clear();
                zipTextBox.Clear();

                /*Isaac added these in*/
                cardNumberTextBox.Clear();
                cityTextBox.Clear();
                stateTextBox.Clear();
                securityNumberTextBox.Clear();
                streaNameTextBox.Clear();

                MCradioB.Checked = false;
                AEradioB.Checked = false;
                VISAradioB.Checked = false;
                EBTradioB.Checked = false;
            }
            else
                MessageBox.Show("Error in taking card data");
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            zipTextBox.Clear();

            /*Isaac added these in*/
            cardNumberTextBox.Clear();
            cityTextBox.Clear();
            stateTextBox.Clear();
            securityNumberTextBox.Clear();
            streaNameTextBox.Clear();

            MCradioB.Checked = false;
            AEradioB.Checked = false;
            VISAradioB.Checked = false;
            EBTradioB.Checked = false;

            this.Close();
        }
    }
}
