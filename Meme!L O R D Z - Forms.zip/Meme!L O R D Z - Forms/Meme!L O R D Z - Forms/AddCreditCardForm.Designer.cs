﻿namespace Meme_L_O_R_D_Z___Forms
{
    partial class AddCreditCardForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.zipTextBox = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.stateTextBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.securityNumberTextBox = new System.Windows.Forms.TextBox();
            this.cardNumberTextBox = new System.Windows.Forms.TextBox();
            this.CCtypes = new System.Windows.Forms.GroupBox();
            this.AEradioB = new System.Windows.Forms.RadioButton();
            this.VISAradioB = new System.Windows.Forms.RadioButton();
            this.EBTradioB = new System.Windows.Forms.RadioButton();
            this.MCradioB = new System.Windows.Forms.RadioButton();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.AddCreditCardButton = new System.Windows.Forms.Button();
            this.CancelButton = new System.Windows.Forms.Button();
            this.streaNameTextBox = new System.Windows.Forms.TextBox();
            this.cityTextBox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.CCtypes.SuspendLayout();
            this.SuspendLayout();
            // 
            // zipTextBox
            // 
            this.zipTextBox.Location = new System.Drawing.Point(451, 142);
            this.zipTextBox.Name = "zipTextBox";
            this.zipTextBox.Size = new System.Drawing.Size(185, 20);
            this.zipTextBox.TabIndex = 39;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(448, 126);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(46, 13);
            this.label11.TabIndex = 38;
            this.label11.Text = "Zipcode";
            // 
            // stateTextBox
            // 
            this.stateTextBox.Location = new System.Drawing.Point(235, 142);
            this.stateTextBox.Name = "stateTextBox";
            this.stateTextBox.Size = new System.Drawing.Size(185, 20);
            this.stateTextBox.TabIndex = 37;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(232, 126);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(32, 13);
            this.label9.TabIndex = 36;
            this.label9.Text = "State";
            // 
            // securityNumberTextBox
            // 
            this.securityNumberTextBox.Location = new System.Drawing.Point(451, 25);
            this.securityNumberTextBox.Name = "securityNumberTextBox";
            this.securityNumberTextBox.Size = new System.Drawing.Size(185, 20);
            this.securityNumberTextBox.TabIndex = 35;
            // 
            // cardNumberTextBox
            // 
            this.cardNumberTextBox.Location = new System.Drawing.Point(235, 28);
            this.cardNumberTextBox.Name = "cardNumberTextBox";
            this.cardNumberTextBox.Size = new System.Drawing.Size(185, 20);
            this.cardNumberTextBox.TabIndex = 34;
            // 
            // CCtypes
            // 
            this.CCtypes.Controls.Add(this.AEradioB);
            this.CCtypes.Controls.Add(this.VISAradioB);
            this.CCtypes.Controls.Add(this.EBTradioB);
            this.CCtypes.Controls.Add(this.MCradioB);
            this.CCtypes.Location = new System.Drawing.Point(12, 12);
            this.CCtypes.Name = "CCtypes";
            this.CCtypes.Size = new System.Drawing.Size(202, 115);
            this.CCtypes.TabIndex = 33;
            this.CCtypes.TabStop = false;
            this.CCtypes.Text = "Select Card Name";
            // 
            // AEradioB
            // 
            this.AEradioB.AutoSize = true;
            this.AEradioB.Location = new System.Drawing.Point(16, 43);
            this.AEradioB.Name = "AEradioB";
            this.AEradioB.Size = new System.Drawing.Size(109, 17);
            this.AEradioB.TabIndex = 18;
            this.AEradioB.TabStop = true;
            this.AEradioB.Text = "American Express";
            this.AEradioB.UseVisualStyleBackColor = true;
            // 
            // VISAradioB
            // 
            this.VISAradioB.AutoSize = true;
            this.VISAradioB.Location = new System.Drawing.Point(16, 66);
            this.VISAradioB.Name = "VISAradioB";
            this.VISAradioB.Size = new System.Drawing.Size(49, 17);
            this.VISAradioB.TabIndex = 17;
            this.VISAradioB.TabStop = true;
            this.VISAradioB.Text = "VISA";
            this.VISAradioB.UseVisualStyleBackColor = true;
            // 
            // EBTradioB
            // 
            this.EBTradioB.AutoSize = true;
            this.EBTradioB.Location = new System.Drawing.Point(16, 89);
            this.EBTradioB.Name = "EBTradioB";
            this.EBTradioB.Size = new System.Drawing.Size(46, 17);
            this.EBTradioB.TabIndex = 16;
            this.EBTradioB.TabStop = true;
            this.EBTradioB.Text = "EBT";
            this.EBTradioB.UseVisualStyleBackColor = true;
            // 
            // MCradioB
            // 
            this.MCradioB.AutoSize = true;
            this.MCradioB.Location = new System.Drawing.Point(16, 20);
            this.MCradioB.Name = "MCradioB";
            this.MCradioB.Size = new System.Drawing.Size(79, 17);
            this.MCradioB.TabIndex = 15;
            this.MCradioB.TabStop = true;
            this.MCradioB.Text = "MasterCard";
            this.MCradioB.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(448, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(85, 13);
            this.label8.TabIndex = 32;
            this.label8.Text = "Secuirty Number";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(232, 12);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(97, 13);
            this.label7.TabIndex = 31;
            this.label7.Text = "Enter Card Number";
            // 
            // AddCreditCardButton
            // 
            this.AddCreditCardButton.Location = new System.Drawing.Point(12, 133);
            this.AddCreditCardButton.Name = "AddCreditCardButton";
            this.AddCreditCardButton.Size = new System.Drawing.Size(95, 29);
            this.AddCreditCardButton.TabIndex = 40;
            this.AddCreditCardButton.Text = "Add Credit Card";
            this.AddCreditCardButton.UseVisualStyleBackColor = true;
            this.AddCreditCardButton.Click += new System.EventHandler(this.AddCreditCardButton_Click);
            // 
            // CancelButton
            // 
            this.CancelButton.Location = new System.Drawing.Point(119, 133);
            this.CancelButton.Name = "CancelButton";
            this.CancelButton.Size = new System.Drawing.Size(95, 29);
            this.CancelButton.TabIndex = 41;
            this.CancelButton.Text = "Cancel";
            this.CancelButton.UseVisualStyleBackColor = true;
            this.CancelButton.Click += new System.EventHandler(this.CancelButton_Click);
            // 
            // streaNameTextBox
            // 
            this.streaNameTextBox.Location = new System.Drawing.Point(451, 82);
            this.streaNameTextBox.Name = "streaNameTextBox";
            this.streaNameTextBox.Size = new System.Drawing.Size(185, 20);
            this.streaNameTextBox.TabIndex = 46;
            // 
            // cityTextBox
            // 
            this.cityTextBox.Location = new System.Drawing.Point(235, 82);
            this.cityTextBox.Name = "cityTextBox";
            this.cityTextBox.Size = new System.Drawing.Size(185, 20);
            this.cityTextBox.TabIndex = 45;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(448, 66);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(66, 13);
            this.label10.TabIndex = 44;
            this.label10.Text = "Street Name";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(232, 66);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(24, 13);
            this.label6.TabIndex = 43;
            this.label6.Text = "City";
            // 
            // AddCreditCardForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(647, 171);
            this.Controls.Add(this.streaNameTextBox);
            this.Controls.Add(this.cityTextBox);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.CancelButton);
            this.Controls.Add(this.AddCreditCardButton);
            this.Controls.Add(this.zipTextBox);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.stateTextBox);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.securityNumberTextBox);
            this.Controls.Add(this.cardNumberTextBox);
            this.Controls.Add(this.CCtypes);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Name = "AddCreditCardForm";
            this.Text = "Add Credit Card";
            this.CCtypes.ResumeLayout(false);
            this.CCtypes.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox zipTextBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox stateTextBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox securityNumberTextBox;
        private System.Windows.Forms.TextBox cardNumberTextBox;
        private System.Windows.Forms.GroupBox CCtypes;
        private System.Windows.Forms.RadioButton AEradioB;
        private System.Windows.Forms.RadioButton VISAradioB;
        private System.Windows.Forms.RadioButton EBTradioB;
        private System.Windows.Forms.RadioButton MCradioB;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button AddCreditCardButton;
        private System.Windows.Forms.Button CancelButton;
        private System.Windows.Forms.TextBox streaNameTextBox;
        private System.Windows.Forms.TextBox cityTextBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label6;
    }
}