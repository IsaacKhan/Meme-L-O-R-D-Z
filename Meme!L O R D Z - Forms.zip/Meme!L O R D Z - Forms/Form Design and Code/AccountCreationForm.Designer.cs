﻿namespace Meme_L_O_R_D_Z___Forms
{
    partial class AccountCreationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.firsttb = new System.Windows.Forms.TextBox();
            this.lastnametb = new System.Windows.Forms.TextBox();
            this.emailtb = new System.Windows.Forms.TextBox();
            this.phonenumbertb = new System.Windows.Forms.TextBox();
            this.passwordtb = new System.Windows.Forms.TextBox();
            this.confirmButton = new System.Windows.Forms.Button();
            this.CancelButton = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.master = new System.Windows.Forms.RadioButton();
            this.ebt = new System.Windows.Forms.RadioButton();
            this.visa = new System.Windows.Forms.RadioButton();
            this.amerexp = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cardnumbertb = new System.Windows.Forms.TextBox();
            this.securitynumbertb = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.citytb = new System.Windows.Forms.TextBox();
            this.statetb = new System.Windows.Forms.TextBox();
            this.streettb = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.zipcodetb = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "First Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Last Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 194);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Email Address";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(21, 143);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Phone Number";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(21, 245);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Password";
            // 
            // firsttb
            // 
            this.firsttb.Location = new System.Drawing.Point(22, 48);
            this.firsttb.Name = "firsttb";
            this.firsttb.Size = new System.Drawing.Size(185, 20);
            this.firsttb.TabIndex = 5;
            // 
            // lastnametb
            // 
            this.lastnametb.Location = new System.Drawing.Point(22, 108);
            this.lastnametb.Name = "lastnametb";
            this.lastnametb.Size = new System.Drawing.Size(185, 20);
            this.lastnametb.TabIndex = 6;
            // 
            // emailtb
            // 
            this.emailtb.Location = new System.Drawing.Point(22, 210);
            this.emailtb.Name = "emailtb";
            this.emailtb.Size = new System.Drawing.Size(185, 20);
            this.emailtb.TabIndex = 7;
            // 
            // phonenumbertb
            // 
            this.phonenumbertb.Location = new System.Drawing.Point(22, 159);
            this.phonenumbertb.Name = "phonenumbertb";
            this.phonenumbertb.Size = new System.Drawing.Size(185, 20);
            this.phonenumbertb.TabIndex = 8;
            // 
            // passwordtb
            // 
            this.passwordtb.Location = new System.Drawing.Point(22, 261);
            this.passwordtb.Name = "passwordtb";
            this.passwordtb.Size = new System.Drawing.Size(185, 20);
            this.passwordtb.TabIndex = 9;
            // 
            // confirmButton
            // 
            this.confirmButton.Location = new System.Drawing.Point(132, 425);
            this.confirmButton.Name = "confirmButton";
            this.confirmButton.Size = new System.Drawing.Size(75, 31);
            this.confirmButton.TabIndex = 10;
            this.confirmButton.Text = "Confirm";
            this.confirmButton.UseVisualStyleBackColor = true;
            this.confirmButton.Click += new System.EventHandler(this.createaccbt_Click);
            // 
            // CancelButton
            // 
            this.CancelButton.Location = new System.Drawing.Point(253, 425);
            this.CancelButton.Name = "CancelButton";
            this.CancelButton.Size = new System.Drawing.Size(75, 31);
            this.CancelButton.TabIndex = 11;
            this.CancelButton.Text = "Cancel";
            this.CancelButton.UseVisualStyleBackColor = true;
            this.CancelButton.Click += new System.EventHandler(this.CancelButton_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(250, 194);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(97, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Enter Card Number";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(250, 245);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(85, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Secuirty Number";
            // 
            // master
            // 
            this.master.AutoSize = true;
            this.master.Location = new System.Drawing.Point(16, 32);
            this.master.Name = "master";
            this.master.Size = new System.Drawing.Size(79, 17);
            this.master.TabIndex = 15;
            this.master.TabStop = true;
            this.master.Text = "MasterCard";
            this.master.UseVisualStyleBackColor = true;
            // 
            // ebt
            // 
            this.ebt.AutoSize = true;
            this.ebt.Location = new System.Drawing.Point(16, 101);
            this.ebt.Name = "ebt";
            this.ebt.Size = new System.Drawing.Size(46, 17);
            this.ebt.TabIndex = 16;
            this.ebt.TabStop = true;
            this.ebt.Text = "EBT";
            this.ebt.UseVisualStyleBackColor = true;
            // 
            // visa
            // 
            this.visa.AutoSize = true;
            this.visa.Location = new System.Drawing.Point(16, 78);
            this.visa.Name = "visa";
            this.visa.Size = new System.Drawing.Size(49, 17);
            this.visa.TabIndex = 17;
            this.visa.TabStop = true;
            this.visa.Text = "VISA";
            this.visa.UseVisualStyleBackColor = true;
            // 
            // amerexp
            // 
            this.amerexp.AutoSize = true;
            this.amerexp.Location = new System.Drawing.Point(16, 55);
            this.amerexp.Name = "amerexp";
            this.amerexp.Size = new System.Drawing.Size(109, 17);
            this.amerexp.TabIndex = 18;
            this.amerexp.TabStop = true;
            this.amerexp.Text = "American Express";
            this.amerexp.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.amerexp);
            this.groupBox1.Controls.Add(this.visa);
            this.groupBox1.Controls.Add(this.ebt);
            this.groupBox1.Controls.Add(this.master);
            this.groupBox1.Location = new System.Drawing.Point(253, 32);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(185, 147);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Select Card Name";
            // 
            // cardnumbertb
            // 
            this.cardnumbertb.Location = new System.Drawing.Point(253, 210);
            this.cardnumbertb.Name = "cardnumbertb";
            this.cardnumbertb.Size = new System.Drawing.Size(185, 20);
            this.cardnumbertb.TabIndex = 21;
            // 
            // securitynumbertb
            // 
            this.securitynumbertb.Location = new System.Drawing.Point(253, 261);
            this.securitynumbertb.Name = "securitynumbertb";
            this.securitynumbertb.Size = new System.Drawing.Size(185, 20);
            this.securitynumbertb.TabIndex = 22;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(19, 301);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(24, 13);
            this.label6.TabIndex = 23;
            this.label6.Text = "City";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(250, 301);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(32, 13);
            this.label9.TabIndex = 24;
            this.label9.Text = "State";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(19, 358);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(66, 13);
            this.label10.TabIndex = 25;
            this.label10.Text = "Street Name";
            // 
            // citytb
            // 
            this.citytb.Location = new System.Drawing.Point(22, 317);
            this.citytb.Name = "citytb";
            this.citytb.Size = new System.Drawing.Size(185, 20);
            this.citytb.TabIndex = 26;
            // 
            // statetb
            // 
            this.statetb.Location = new System.Drawing.Point(253, 317);
            this.statetb.Name = "statetb";
            this.statetb.Size = new System.Drawing.Size(185, 20);
            this.statetb.TabIndex = 27;
            // 
            // streettb
            // 
            this.streettb.Location = new System.Drawing.Point(22, 374);
            this.streettb.Name = "streettb";
            this.streettb.Size = new System.Drawing.Size(185, 20);
            this.streettb.TabIndex = 28;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(250, 358);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(46, 13);
            this.label11.TabIndex = 29;
            this.label11.Text = "Zipcode";
            // 
            // zipcodetb
            // 
            this.zipcodetb.Location = new System.Drawing.Point(253, 374);
            this.zipcodetb.Name = "zipcodetb";
            this.zipcodetb.Size = new System.Drawing.Size(185, 20);
            this.zipcodetb.TabIndex = 30;
            // 
            // AccountCreationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(468, 468);
            this.Controls.Add(this.zipcodetb);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.streettb);
            this.Controls.Add(this.statetb);
            this.Controls.Add(this.citytb);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.securitynumbertb);
            this.Controls.Add(this.cardnumbertb);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.CancelButton);
            this.Controls.Add(this.confirmButton);
            this.Controls.Add(this.passwordtb);
            this.Controls.Add(this.phonenumbertb);
            this.Controls.Add(this.emailtb);
            this.Controls.Add(this.lastnametb);
            this.Controls.Add(this.firsttb);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "AccountCreationForm";
            this.Text = "Account Creation";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox firsttb;
        private System.Windows.Forms.TextBox lastnametb;
        private System.Windows.Forms.TextBox emailtb;
        private System.Windows.Forms.TextBox phonenumbertb;
        private System.Windows.Forms.TextBox passwordtb;
        private System.Windows.Forms.Button confirmButton;
        private System.Windows.Forms.Button CancelButton;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RadioButton master;
        private System.Windows.Forms.RadioButton ebt;
        private System.Windows.Forms.RadioButton visa;
        private System.Windows.Forms.RadioButton amerexp;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox cardnumbertb;
        private System.Windows.Forms.TextBox securitynumbertb;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox citytb;
        private System.Windows.Forms.TextBox statetb;
        private System.Windows.Forms.TextBox streettb;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox zipcodetb;
    }
}